package com.example.local_notification_app_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
